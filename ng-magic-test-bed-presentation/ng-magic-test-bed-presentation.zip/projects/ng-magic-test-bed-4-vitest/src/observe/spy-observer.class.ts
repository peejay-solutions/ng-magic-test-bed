import { Observable } from 'rxjs';
import { Spy, spyFunctionOf } from '../spy-framework/spy-framework';


/**
 * @description
 * Subscribes to a given observable and tracks all observations.
 */
export class SpyObserver<T> {
    /**
     * @description
     * your test framework's spy that will be called when the observable emits a value.
     * Can be uses like this: expect(observer.next).toHaveBeenCalledWith(expectedValue);
     */
    public readonly next: Spy;
     /**
     * @description
     * your test framework's spy that will be called when the observable throws an error
     * Can be uses like this: expect(observer.next).toHaveBeenCalledWith(expectedError);
     */
    public readonly error: Spy;
    /**
     * @description
     * your test framework's spy that will be called when the observable completes
     * Can be uses like this: expect(observer.complete).toHaveBeenCalled();
     */
    public readonly complete: Spy;
    /**
     * @description
     * When the observable emits a value, it will be pushed onto this array.
     */
    public readonly observations: Array<T> = [];
     /**
     * @description
     * refers to the latest emitted value of the observable.
     */
    public get latest(): T {
        return this.observations[this.observations.length - 1];
    }
    /**
     * @param observable
     * The observable that you want to spy with this observer instance.
     * @param name
     * Optional name that prefixes all spies that are created by the observer. This makes it easier to read the
     * test output if anything fails.
     */
    constructor(observable: Observable<T>, name?: string) {
        const prefix = name ? name + '.' : '';
        const inner = { [prefix + 'next']: ()=>{}, [prefix + 'complete']: ()=>{}, [prefix + 'error']: ()=>{}};

        spyFunctionOf(inner, prefix + 'next');
        spyFunctionOf(inner, prefix + 'complete');
        spyFunctionOf(inner, prefix + 'error');
        this.next = inner[prefix + 'next'] as Spy;
        this.complete = inner[prefix + 'complete'] as Spy;
        this.error = inner[prefix + 'error'] as Spy;
        this.observations = new Array<T>();
        observable.subscribe(next => {
            this.observations.push(next);
            this.next(next);
        }, this.error, this.complete);
    }
}
