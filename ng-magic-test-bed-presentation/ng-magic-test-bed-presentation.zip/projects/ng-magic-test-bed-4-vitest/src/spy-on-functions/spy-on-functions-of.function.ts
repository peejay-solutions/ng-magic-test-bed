import { spyFunctionOf } from '../spy-framework/spy-framework';

/** @description converts methods of target into spies of your test framework.
 * @param target target's methods will be overwritten with spies. Inherited methods will be overwritten at target object and not
 * on the prototype. This avoids unpleasant side effects.
 * @param source this optional param can be used to create additional spies at the target object. For each method on 
 * source and its prototypes a spy will be created on the target.
 */
export function spyOnFunctionsOf(target: any, source?: any) {
    if (typeof target !== 'object' || target === null) {
        throw new Error('NgMagicTestBed: expected parameter target to be object');
    }
    if (typeof source === 'undefined') {
        source = target;
    }
    if (typeof source !== 'object' || source === null) {
        throw new Error('NgMagicTestBed: expected parameter source to be object');
    }
    const sourceKeys = getMethodKeysFromObject(source);
    const targetKeys = getMethodKeysFromObject(target);
    sourceKeys.forEach(key => {
        spyFunctionOf(target, key);
    });
    targetKeys.forEach(key => {
        if (sourceKeys.includes(key)) {
            return;
        }
        spyFunctionOf(target, key);
    });
    return target;
}


function getMethodKeysFromObject(obj: any) {
    const keys: Array<string> = [];

    collectFunctionKeys(obj, obj, keys);

    let currentPrototype = Object.getPrototypeOf(obj);
    while (currentPrototype && currentPrototype.constructor !== Object && currentPrototype.constructor !== Array) {
        collectFunctionKeys(obj, currentPrototype, keys);
        currentPrototype = Object.getPrototypeOf(currentPrototype);
    }

    return keys;
}

function collectFunctionKeys(obj: any, source: any, keys: Array<string>) {
    Object.getOwnPropertyNames(source).forEach(key => {
        try {
            if (key !== 'constructor' && keys.indexOf(key) < 0 && typeof obj[key] === 'function') {
                keys.push(key);
            }
        } catch (e) {

        }
    });
}
